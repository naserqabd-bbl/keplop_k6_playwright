# k6 + Grafana

Default `run.sh` uses `--network host` for simplicity (best on Linux).

If you're on macOS/Windows, use the docker gateway host:
- BASE_URL=http://host.docker.internal:3000
- K6_OUT=influxdb=http://host.docker.internal:8086/k6

Example:

```bash
docker run --rm \
  -e K6_OUT=influxdb=http://host.docker.internal:8086/k6 \
  -e BASE_URL=http://host.docker.internal:3000 \
  -v "$(pwd)/perf/k6:/scripts" \
  grafana/k6:0.54.0 run /scripts/profile.js
```
