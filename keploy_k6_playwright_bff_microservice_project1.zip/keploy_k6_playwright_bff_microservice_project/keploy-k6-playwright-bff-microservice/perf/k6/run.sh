#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${ROOT_DIR}"

remove_container_if_exists() {
  local name="$1"
  if docker ps -a --format '{{.Names}}' | grep -Fxq "${name}"; then
    docker rm -f "${name}" >/dev/null
  fi
}

ensure_bff_ready() {
  if curl -fsS "http://localhost:3000/health" >/dev/null 2>&1; then
    return
  fi

  cat >&2 <<'EOF'
BFF is not reachable at http://localhost:3000/health.
Start the app stack first, then rerun:
  make up
  make k6-run
EOF
  exit 1
}

# Clean up stale perf containers/networks from older compose projects.
remove_container_if_exists "k6_influxdb"
remove_container_if_exists "k6_grafana"
docker compose -f docker-compose.perf.yml down -v --remove-orphans >/dev/null 2>&1 || true
docker network rm k6_perf_net >/dev/null 2>&1 || true

# Ensure perf stack is up (InfluxDB + Grafana)
docker compose -f docker-compose.perf.yml up -d

ensure_bff_ready

# Run k6 (official image) and send metrics to InfluxDB
docker run --rm \
  --network host \
  -e K6_OUT=influxdb=http://localhost:8086/k6 \
  -e BASE_URL=http://localhost:3000 \
  -v "$(pwd)/perf/k6:/scripts" \
  grafana/k6:0.54.0 run /scripts/profile.js
