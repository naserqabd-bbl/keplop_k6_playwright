#!/usr/bin/env bash
set -euo pipefail

require_linux_tracing() {
  if [[ "$(uname -s)" != "Linux" ]]; then
    cat >&2 <<'EOF'
Keploy network hooks require a Linux kernel with debugfs/tracefs.
Detected a non-Linux host. Run this target from WSL2/Linux VM/native Linux.
EOF
    exit 1
  fi

  if ! grep -qE '[[:space:]]/sys/kernel/debug[[:space:]]' /proc/mounts || \
     ! grep -qE '[[:space:]]/sys/kernel/tracing[[:space:]]' /proc/mounts; then
    cat >&2 <<'EOF'
Missing required kernel mounts for Keploy:
- /sys/kernel/debug (debugfs)
- /sys/kernel/tracing (tracefs)

Try:
  sudo mount -t debugfs debugfs /sys/kernel/debug
  sudo mount -t tracefs nodev /sys/kernel/tracing
EOF
    exit 1
  fi
}

RUNNER_IMAGE="${KEPLOY_RUNNER_IMAGE:-keploy-with-docker-ce}"
RECORD_TIMER="${RECORD_TIMER:-90s}"
BUILD_DELAY="${BUILD_DELAY:-45}"

ensure_runner_image() {
  if docker image inspect "${RUNNER_IMAGE}" >/dev/null 2>&1; then
    return
  fi

  echo "Building Keploy runner image (${RUNNER_IMAGE})..."
  docker build -t "${RUNNER_IMAGE}" -f keploy/scripts/Dockerfile.keploy-docker-ce .
}

run_keploy() {
  local output status
  local -a cmd=(
    docker run --rm
    --network host
    --privileged
    --pid=host
    --entrypoint /app/keploy
    -v /sys/kernel/debug:/sys/kernel/debug
    -v /sys/kernel/tracing:/sys/kernel/tracing
    -v /var/run/docker.sock:/var/run/docker.sock
    -v "$(pwd):/workspace"
    -w /workspace
    -v "$(pwd)/keploy:/keploy-data"
    "${RUNNER_IMAGE}"
    "$@"
  )

  set +e
  output="$("${cmd[@]}" 2>&1)"
  status=$?
  set -e

  if [[ "$status" -eq 0 ]]; then
    printf '%s\n' "$output"
    return 0
  fi

  if grep -qi "error getting credentials" <<<"$output"; then
    local tmp_docker_config
    tmp_docker_config="$(mktemp -d)"
    printf '{"auths":{}}\n' >"${tmp_docker_config}/config.json"
    echo "Docker credential helper failed; retrying Keploy container pull without credential store..." >&2
    DOCKER_CONFIG="${tmp_docker_config}" "${cmd[@]}"
    status=$?
    rm -rf "${tmp_docker_config}"
    return "$status"
  fi

  printf '%s\n' "$output" >&2
  return "$status"
}

require_linux_tracing
ensure_runner_image

mkdir -p keploy/tests

# Avoid container name conflicts before handing startup to Keploy.
docker compose down -v >/dev/null 2>&1 || true

# Generate traffic while Keploy is actively recording.
generate_sample_traffic() {
  local ready=0
  echo "Waiting for BFF and user-service health endpoints..."
  for _ in {1..120}; do
    if curl -fsS http://localhost:3000/health >/dev/null 2>&1 && \
       curl -fsS http://localhost:8000/health >/dev/null 2>&1; then
      ready=1
      break
    fi
    sleep 1
  done

  if [[ "$ready" -ne 1 ]]; then
    echo "Skipping sample traffic: services did not become ready in time." >&2
    return 0
  fi

  echo "Generating sample traffic..."
  for _ in {1..5}; do
    curl -fsS http://localhost:3000/api/v1/profile/1 >/dev/null 2>&1 || true
    curl -fsS http://localhost:3000/api/v1/profile/2 >/dev/null 2>&1 || true
    curl -fsS http://localhost:3000/api/v1/profile/3 >/dev/null 2>&1 || true
    sleep 1
  done
}

initial_count="$(find keploy -type f \( -path '*/tests/*.yaml' -o -path '*/tests/*.yml' \) | wc -l | tr -d '[:space:]')"

generate_sample_traffic &
traffic_pid=$!

# Run Keploy in record mode while Keploy starts the compose stack itself.
# Recordings are written to /keploy-data (mounted to ./keploy on host).
echo "Starting Keploy (record)..."
set +e
run_keploy record \
  -c "docker compose up --build" \
  --cmd-type docker-compose \
  --container-name bff \
  --network-name keploy_demo_net \
  --build-delay "${BUILD_DELAY}" \
  --record-timer "${RECORD_TIMER}" \
  --path /keploy-data
keploy_status=$?
set -e

wait "$traffic_pid" || true

record_count="$(find keploy -type f \( -path '*/tests/*.yaml' -o -path '*/tests/*.yml' \) | wc -l | tr -d '[:space:]')"
new_count="$((record_count - initial_count))"
if [[ "$new_count" -le 0 ]]; then
  echo "No Keploy recordings were created. Keploy exited with status ${keploy_status}." >&2
  echo "Expected recordings under: keploy/keploy/test-set-*/tests" >&2
  exit 1
fi

if [[ "$keploy_status" -ne 0 ]]; then
  echo "Warning: Keploy exited with status ${keploy_status}, but ${new_count} new test file(s) were recorded." >&2
fi

echo "Done. Recorded ${new_count} new Keploy test file(s) (${record_count} total)."
