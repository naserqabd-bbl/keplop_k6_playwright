#!/usr/bin/env bash
set -euo pipefail

require_linux_tracing() {
  if [[ "$(uname -s)" != "Linux" ]]; then
    cat >&2 <<'EOF'
Keploy network hooks require a Linux kernel with debugfs/tracefs.
Detected a non-Linux host. Run this target from WSL2/Linux VM/native Linux.
EOF
    exit 1
  fi

  if ! grep -qE '[[:space:]]/sys/kernel/debug[[:space:]]' /proc/mounts || \
     ! grep -qE '[[:space:]]/sys/kernel/tracing[[:space:]]' /proc/mounts; then
    cat >&2 <<'EOF'
Missing required kernel mounts for Keploy:
- /sys/kernel/debug (debugfs)
- /sys/kernel/tracing (tracefs)

Try:
  sudo mount -t debugfs debugfs /sys/kernel/debug
  sudo mount -t tracefs nodev /sys/kernel/tracing
EOF
    exit 1
  fi
}

RUNNER_IMAGE="${KEPLOY_RUNNER_IMAGE:-keploy-with-docker-ce}"
BUILD_DELAY="${BUILD_DELAY:-45}"
TEST_DELAY="${KEPLOY_TEST_DELAY:-10}"
API_TIMEOUT="${KEPLOY_API_TIMEOUT:-15}"

ensure_runner_image() {
  if docker image inspect "${RUNNER_IMAGE}" >/dev/null 2>&1; then
    return
  fi

  echo "Building Keploy runner image (${RUNNER_IMAGE})..."
  docker build -t "${RUNNER_IMAGE}" -f keploy/scripts/Dockerfile.keploy-docker-ce .
}

run_keploy() {
  local output status
  local -a cmd=(
    docker run --rm
    --network host
    --privileged
    --pid=host
    --entrypoint /app/keploy
    -v /sys/kernel/debug:/sys/kernel/debug
    -v /sys/kernel/tracing:/sys/kernel/tracing
    -v /var/run/docker.sock:/var/run/docker.sock
    -v "$(pwd):/workspace"
    -w /workspace
    -v "$(pwd)/keploy:/keploy-data"
    "${RUNNER_IMAGE}"
    "$@"
  )

  set +e
  output="$("${cmd[@]}" 2>&1)"
  status=$?
  set -e

  if [[ "$status" -eq 0 ]]; then
    printf '%s\n' "$output"
    return 0
  fi

  if grep -qi "error getting credentials" <<<"$output"; then
    local tmp_docker_config
    tmp_docker_config="$(mktemp -d)"
    printf '{"auths":{}}\n' >"${tmp_docker_config}/config.json"
    echo "Docker credential helper failed; retrying Keploy container pull without credential store..." >&2
    DOCKER_CONFIG="${tmp_docker_config}" "${cmd[@]}"
    status=$?
    rm -rf "${tmp_docker_config}"
    return "$status"
  fi

  printf '%s\n' "$output" >&2
  return "$status"
}

require_linux_tracing
ensure_runner_image

test_count="$(find keploy -type f \( -path '*/tests/*.yaml' -o -path '*/tests/*.yml' \) | wc -l | tr -d '[:space:]')"
if [[ "$test_count" == "0" ]]; then
  echo "No Keploy test files found under keploy/keploy/test-set-*/tests. Run keploy record first." >&2
  exit 1
fi

# Avoid container name conflicts before startup is handed to Keploy.
docker compose down -v >/dev/null 2>&1 || true

echo "Running Keploy tests (replay)..."
run_keploy test \
  -c "docker compose up --build" \
  --cmd-type docker-compose \
  --container-name bff \
  --network-name keploy_demo_net \
  --build-delay "${BUILD_DELAY}" \
  --delay "${TEST_DELAY}" \
  --api-timeout "${API_TIMEOUT}" \
  --path /keploy-data

echo "Done."
