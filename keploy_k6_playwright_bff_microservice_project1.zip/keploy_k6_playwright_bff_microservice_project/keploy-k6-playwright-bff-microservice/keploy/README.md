# Keploy

This folder contains helper scripts and the place where Keploy stores recorded tests.

- Recorded tests are stored under `keploy/keploy/test-set-*/tests/`.
- `keploy/scripts/record.sh` runs record mode and generates sample traffic.
- `keploy/scripts/test.sh` runs replay mode.
- First run builds a helper image (`keploy-with-docker-ce`) so Keploy can run `docker compose` internally.
- You can increase record duration: `RECORD_TIMER=120s make keploy-record`.

If you want to record additional flows, run `record.sh` and hit more endpoints while recording.
