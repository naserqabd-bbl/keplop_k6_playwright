# BFF + Microservice Contract Testing + Grafana k6 (Ready-to-run)

This repo is a **ready-to-use starter** that includes:

- A **Microservice** (`service/`) exposing a simple REST API
- A **BFF** (`bff/`) that consumes the microservice and exposes its own API
- **Contract testing** with **Pact**:
  - Consumer contract tests in `bff/test/pact/`
  - Provider verification in `service/test/pact/`
- **Load + smoke testing** with **Grafana k6**:
  - k6 scripts in `k6/`
  - `docker-compose` for **InfluxDB + Grafana**
  - Grafana provisioning (datasource + dashboard) in `grafana/`

## Quick start (Docker)

### 1) Start service + BFF
```bash
docker compose up -d service bff
```

Health checks:
- Service: http://localhost:3001/health
- BFF: http://localhost:3000/health

### 2) Run contract tests (Pact)
Generate consumer pact from BFF:
```bash
cd bff
npm ci
npm run test:pact:consumer
```

Verify provider against generated pact:
```bash
cd ../service
npm ci
npm run test:pact:provider
```

Pact files are written to `./pacts`.

### 3) Start Grafana stack (InfluxDB + Grafana)
From repo root:
```bash
docker compose up -d influxdb grafana
```

Grafana: http://localhost:3002  
- user: `admin`
- pass: `admin`

InfluxDB (v1): http://localhost:8086  
DB: `k6`

### 4) Run k6 smoke test
```bash
docker compose run --rm k6-smoke
```

### 5) Run k6 load test
```bash
docker compose run --rm k6-load
```

k6 writes results to InfluxDB, and Grafana shows them using the provisioned dashboard.

## Local dev (without Docker)
Open two terminals:

Service:
```bash
cd service
npm ci
npm run dev
```

BFF:
```bash
cd bff
npm ci
npm run dev
```

Then run k6 locally (if installed):
```bash
k6 run k6/smoke_contract.js
k6 run k6/load.js
```

## Project layout
```
.
├─ bff/                 # consumer + pact consumer tests
├─ service/             # provider + pact provider verification
├─ k6/                  # k6 scripts
├─ grafana/             # provisioning (datasource + dashboard)
├─ pacts/               # generated pact files (gitignored)
└─ docker-compose.yml
```

## Notes
- The example contracts cover:
  - `GET /v1/users/:id` on the service
  - `GET /v1/profile/:id` on the BFF
- You can extend with more endpoints and Pact interactions.
