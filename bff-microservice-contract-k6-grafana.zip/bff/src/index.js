const express = require("express");
const axios = require("axios");

const PORT = process.env.PORT || 3000;
const SERVICE_BASE_URL = process.env.SERVICE_BASE_URL || "http://localhost:3001";

const app = express();
app.use(express.json());

app.get("/health", (_req, res) => res.json({ ok: true, service: "bff" }));

/**
 * BFF endpoint:
 * GET /v1/profile/:id
 * - fetches user from service
 * - returns a BFF-shaped response
 */
app.get("/v1/profile/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const r = await axios.get(`${SERVICE_BASE_URL}/v1/users/${id}`, { timeout: 1000 });

    return res.json({
      user: r.data,
      meta: { source: "service", fetchedAt: new Date().toISOString() },
    });
  } catch (err) {
    const status = err?.response?.status || 502;
    return res.status(status).json({ error: "UPSTREAM_ERROR", status });
  }
});

app.listen(PORT, () => console.log(`bff listening on :${PORT}`));
