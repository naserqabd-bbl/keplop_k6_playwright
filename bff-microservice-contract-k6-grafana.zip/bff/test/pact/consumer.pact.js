/**
 * Consumer pact test for BFF -> Service contract.
 * Generates pact file at ./pacts/bff-service.json
 *
 * Run:
 *   cd bff
 *   npm ci
 *   npm run test:pact:consumer
 */
const path = require("path");
const axios = require("axios");
const { PactV3, MatchersV3 } = require("@pact-foundation/pact");

const { like } = MatchersV3;

const pact = new PactV3({
  consumer: "bff",
  provider: "service",
  dir: path.resolve(__dirname, "../../../pacts"),
  logLevel: "info",
});

(async () => {
  await pact
    .addInteraction()
    .given("user 123 exists")
    .uponReceiving("a request for user 123")
    .withRequest({
      method: "GET",
      path: "/v1/users/123",
      headers: { Accept: "application/json" },
    })
    .willRespondWith({
      status: 200,
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: {
        id: like("123"),
        email: like("user123@example.com"),
        name: like("User 123"),
      },
    });

  await pact.executeTest(async (mockServer) => {
    const res = await axios.get(`${mockServer.url}/v1/users/123`, {
      headers: { Accept: "application/json" },
      timeout: 1000,
    });

    if (res.status !== 200) throw new Error(`unexpected status ${res.status}`);
    if (!res.data || res.data.id !== "123") throw new Error("unexpected body");
  });

  console.log("Consumer pact generated in ./pacts");
})();
