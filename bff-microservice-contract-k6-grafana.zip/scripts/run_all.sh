#!/usr/bin/env sh
set -e

echo "Starting service and bff..."
docker compose up -d service bff

echo "Running BFF pact consumer test..."
( cd bff && npm ci && npm run test:pact:consumer )

echo "Running Service pact provider verification..."
( cd service && npm ci && npm run test:pact:provider )

echo "Starting grafana stack..."
docker compose up -d influxdb grafana

echo "Running k6 smoke test..."
docker compose run --rm k6-smoke

echo "Done."
