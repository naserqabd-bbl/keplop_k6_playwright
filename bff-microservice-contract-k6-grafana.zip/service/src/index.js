const express = require("express");

const PORT = process.env.PORT || 3001;

const app = express();
app.use(express.json());

// simple in-memory seed
const USERS = {
  "123": { id: "123", email: "user123@example.com", name: "User 123" },
  "999": { id: "999", email: "user999@example.com", name: "User 999" },
};

app.get("/health", (_req, res) => res.json({ ok: true, service: "service" }));

app.get("/v1/users/:id", (req, res) => {
  const u = USERS[req.params.id];
  if (!u) return res.status(404).json({ error: "NOT_FOUND" });
  return res.json(u);
});

app.listen(PORT, () => {
  console.log(`service listening on :${PORT}`);
});
