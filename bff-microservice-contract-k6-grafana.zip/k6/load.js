\
import http from "k6/http";
import { check, sleep } from "k6";

const BFF_BASE_URL = __ENV.BFF_BASE_URL || "http://localhost:3000";

export const options = {
  scenarios: {
    ramping: {
      executor: "ramping-vus",
      startVUs: 0,
      stages: [
        { duration: "20s", target: 10 },
        { duration: "40s", target: 25 },
        { duration: "20s", target: 0 },
      ],
      gracefulRampDown: "10s",
    },
  },
  thresholds: {
    http_req_failed: ["rate<0.01"],
    http_req_duration: ["p(95)<800", "p(99)<1500"],
    checks: ["rate>0.98"],
  },
};

export default function () {
  const id = Math.random() < 0.7 ? "123" : "999"; // 999 exists too, see service seed
  const res = http.get(`${BFF_BASE_URL}/v1/profile/${id}`);
  check(res, {
    "status 200": (r) => r.status === 200,
    "json": (r) => (r.headers["Content-Type"] || "").includes("application/json"),
  });
  sleep(Math.random() * 0.3);
}
