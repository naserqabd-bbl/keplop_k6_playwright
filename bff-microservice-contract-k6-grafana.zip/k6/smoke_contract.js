\
import http from "k6/http";
import { check, sleep } from "k6";

const BFF_BASE_URL = __ENV.BFF_BASE_URL || "http://localhost:3000";
const SERVICE_BASE_URL = __ENV.SERVICE_BASE_URL || "http://localhost:3001";

export const options = {
  vus: 1,
  iterations: 10,
  thresholds: {
    http_req_failed: ["rate==0"],
    http_req_duration: ["p(95)<500"],
  },
};

function assertJson(res, path, predicate, name) {
  const body = res.json();
  const ok = predicate(body);
  check(res, { [name]: () => ok });
  return body;
}

export default function () {
  // Service contract smoke: GET /v1/users/:id
  const s = http.get(`${SERVICE_BASE_URL}/v1/users/123`);
  check(s, {
    "service status 200": (r) => r.status === 200,
    "service content-type json": (r) => (r.headers["Content-Type"] || "").includes("application/json"),
  });
  assertJson(
    s,
    "$",
    (b) => b && b.id === "123" && typeof b.email === "string" && typeof b.name === "string",
    "service shape: {id,email,name}"
  );

  // BFF contract smoke: GET /v1/profile/:id
  const b = http.get(`${BFF_BASE_URL}/v1/profile/123`);
  check(b, {
    "bff status 200": (r) => r.status === 200,
    "bff content-type json": (r) => (r.headers["Content-Type"] || "").includes("application/json"),
  });
  assertJson(
    b,
    "$",
    (p) => p && p.user && p.user.id === "123" && p.user.email && p.meta && p.meta.source === "service",
    "bff shape: {user,meta}"
  );

  sleep(0.2);
}
